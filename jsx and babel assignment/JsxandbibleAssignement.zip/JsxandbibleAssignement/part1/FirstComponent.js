/** Named Component: super-basic static. */

function FirstComponent() {
  return <h1>My very first component.</h1>;
}
